library(testthat)
library(RFate)

test_check("RFate")
