### HEADER #####################################################################
##' 
##' @useDynLib RFate, .registration = TRUE
##' 
##' @importFrom Rcpp sourceCpp
##' 
## END OF HEADER ###############################################################

NULL
