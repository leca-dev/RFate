# ### HEADER #####################################################################
# ##' @title Create the skeleton folder for a \code{FATE} simulation
# ##' 
# ##' @name PRE_FATE.previsions
# ##'
# ##' @author Maya Guéguen
# ##' 
# ##' @description This script is designed to create a user-friendly directory 
# ##' tree to run a \code{FATE} simulation.
# ##'              
# ##' @param name.simulation a \code{string} that will be used as the main 
# ##' directory and simulation name
# ##' 
# ##' @details 
# ##' 
# ##' \code{FATE} requires only one input parameter (see 
# ##' \code{\link{PRE_FATE.params_simulParameters}}), 
# ##' 
# ##' \itemize{
# ##'   \item which is a file containing the names of parameter files,
# ##'   \item which may themselves contain 
# ##'   \itemize{
# ##'     \item parameters (e.g. succession, dispersal files...)
# ##'     \item or other file names (e.g. disturbance or environmental change 
# ##'     masks).
# ##'   }
# ##' }
# ##' 
# ##' The user could give names of files stored everywhere on a machine, and does 
# ##' not have to put them all in one same place. \cr
# ##' But as this is more practical, this function proposes a way to 
# ##' \strong{organize all those files or parameter files} that will or could be 
# ##' used by a \code{FATE} simulation. \cr \cr
# ##' 
# ##' The tree structure is detailed below :
# ##' 
# ##' \describe{
# ##'   \item{\code{DATA}}{this folder will contain all the data or parameters 
# ##'   that are needed by the model
# ##'   \describe{
# ##'     \item{\code{GLOBAL_PARAMETERS}}{files containing global parameters for 
# ##'     the simulation \cr (see \code{\link{PRE_FATE.params_globalParameters}})}
# ##'     \item{\code{MASK}}{raster maps used in the model}
# ##'     \item{\code{SCENARIO}}{files containing information about changes in
# ##'     raster maps input \cr (see \code{\link{PRE_FATE.params_changingYears}})}
# ##'     \item{\code{SAVE}}{files containing information about simulation times 
# ##'     to save outputs \cr (see \code{\link{PRE_FATE.params_savingYears}})}
# ##'     \item{\code{PFGS}}{ \cr
# ##'     \describe{
# ##'       \item{\code{SUCC}}{life history parameter files \cr 
# ##'       (see \code{\link{PRE_FATE.params_PFGsuccession}})}
# ##'       \item{\code{LIGHT}}{response to light interaction parameter files \cr 
# ##'       (see \code{\link{PRE_FATE.params_PFGlight}})}
# ##'       \item{\code{SOIL}}{response to soil interaction parameter files \cr 
# ##'       (see \code{\link{PRE_FATE.params_PFGsoil}})}
# ##'       \item{\code{DISP}}{dispersal parameter files \cr 
# ##'       (see \code{\link{PRE_FATE.params_PFGdispersal}})}
# ##'       \item{\code{HABSUIT}}{habitat suitability maps}
# ##'       \item{\code{DIST}}{response to disturbances parameter files \cr 
# ##'       (see \code{\link{PRE_FATE.params_PFGdisturbance}})}
# ##'       \item{\code{DROUGHT}}{response to drought disturbance parameter files 
# ##'       \cr (see \code{\link{PRE_FATE.params_PFGdrought}})}
# ##'       \item{\code{ALIENS}}{aliens introduction maps}
# ##'     }
# ##'     }
# ##'   }
# ##'   }
# ##'   \item{\code{PARAM_SIMUL}}{this folder will contain simulation files that can be
# ##'   given as input to the software \cr (see 
# ##'   \code{\link{PRE_FATE.params_simulParameters}})}
# ##'   \item{\code{RESULTS}}{this folder will collect all the results produced by the
# ##'   software with a folder for each simulation}
# ##' }
# ##' 
# ##' \strong{NB :} \cr
# ##' All the functions of the \code{RFate} package are based on this folder 
# ##' structure.
# ##' 
# ##' 
# ##' @return A directory tree with folders to contain the parameter files, the
# ##' simulation files and the results.
# ##' 
# ##' @keywords folder structure
# ##' 
# ##' @seealso \code{\link{PRE_FATE.params_globalParameters}},
# ##' \code{\link{PRE_FATE.params_PFGsuccession}},
# ##' \code{\link{PRE_FATE.params_PFGlight}},
# ##' \code{\link{PRE_FATE.params_PFGsoil}},
# ##' \code{\link{PRE_FATE.params_PFGdispersal}},
# ##' \code{\link{PRE_FATE.params_PFGdisturbance}},
# ##' \code{\link{PRE_FATE.params_PFGdrought}},
# ##' \code{\link{PRE_FATE.params_changingYears}},
# ##' \code{\link{PRE_FATE.params_savingYears}},
# ##' \code{\link{PRE_FATE.params_simulParameters}}
# ##' 
# ##' 
# ##' @export
# ##'
# ## END OF HEADER ###############################################################
# 
# 
# PRE_FATE.previsions = function(name.simulation = "FATE_simulation")
# {
#   #############################################################################
#   
#   ## CHECK parameter name.simulation
#   .testParam_existFolder(name.simulation, "PARAM_SIMUL/")
#   .testParam_existFolder(name.simulation, "DATA/")
#   name.simulation = sub("/", "", name.simulation)
#   ## CHECK parameter file.simulParam
#   abs.simulParams = .getParam_abs.simulParams(file.simulParam, name.simulation)
#   
#   #############################################################################
#   
#   res = foreach (abs.simulParam = abs.simulParams) %do%
#     {
#       
#       cat("\n+++++++\n")
#       cat("\n  Simulation name : ", name.simulation)
#       cat("\n  Simulation file : ", abs.simulParam)
#       cat("\n")
#       
#       ## Get number of PFGs -----------------------------------------------------
#       ## Get PFG names ----------------------------------------------------------
#       GLOB_SIM = .getGraphics_PFG(name.simulation  = name.simulation
#                                   , abs.simulParam = abs.simulParam)
#       
#       ## Get raster mask --------------------------------------------------------
#       GLOB_MASK = .getGraphics_mask(name.simulation  = name.simulation
#                                     , abs.simulParam = abs.simulParam)
#       
#       ## Get saving options -----------------------------------------------------
#       file.globalParam = .getParam(params.lines = abs.simulParam
#                                    , flag = "GLOBAL_PARAMS"
#                                    , flag.split = "^--.*--$"
#                                    , is.num = FALSE)
#       list.saving = c("SAVING_ABUND_PFG_STRATUM", "SAVING_ABUND_PFG", "SAVING_ABUND_STRATUM"
#                       , "DISPERSAL_SAVING", "LIGHT_SAVING", "SOIL_SAVING")
#       GLOB_SAVING = sapply(list.saving, function(x){
#         .getParam(params.lines = paste0(sub(basename(name.simulation), "", name.simulation)
#                                         , file.globalParam)
#                   , flag = x
#                   , flag.split = " "
#                   , is.num = TRUE)
#       })
#       names(GLOB_SAVING) = list.SAVING
#       file.savingYears = .getParam(params.lines = abs.simulParam
#                                    , flag = "SAVING_YEARS_MAPS"
#                                    , flag.split = "^--.*--$"
#                                    , is.num = FALSE)
#       
#       no_YEARS = readLines(file.savingYears)
#       no_YEARS = length(which(nchar(no_YEARS) > 0))
#       
#       
#       ## ----------------------------------------------------------------------
#       
#       no_d = GLOB_SIM$doDisp * GLOB_SAVING$DISPERSAL_SAVING * no_YEARS * GLOB_SIM$no_PFG
#       no_s = GLOB_SIM$doSoil * GLOB_SAVING$SOIL_SAVING * no_YEARS
#       no_l = GLOB_SIM$doLight * GLOB_SAVING$LIGHT_SAVING * no_YEARS * GLOB_SIM$no_STRATA
#       
#       no_str = GLOB_SAVING$SAVING_ABUND_STRATUM * no_YEARS * GLOB_SIM$no_STRATA
#       no_pfg = GLOB_SAVING$SAVING_ABUND_PFG * no_YEARS * GLOB_SIM$no_PFG
#       no_pfg_str = GLOB_SAVING$SAVING_ABUND_PFG_STRATUM * no_YEARS * GLOB_SIM$no_STRATA * GLOB_SIM$no_PFG
# 
#             
#       ## ----------------------------------------------------------------------
#       
#       no_pix = GLOB_MASK$no_1_mask
#       no_time1 = .getParam(params.lines = paste0(sub(basename(name.simulation), "", name.simulation)
#                                                  , file.globalParam)
#                            , flag = "SEEDING_DURATION"
#                            , flag.split = " "
#                            , is.num = TRUE)
#       no_time2 = .getParam(params.lines = paste0(sub(basename(name.simulation), "", name.simulation)
#                                                  , file.globalParam)
#                            , flag = "SIMULATION_DURATION"
#                            , flag.split = " "
#                            , is.num = TRUE)
#       
# 
#       
#       
#       
#     }
# }
# 
# 
