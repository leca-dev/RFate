#include <stdio.h>
#include <stdlib.h>
#include <proj.h>
int main(void) {
	proj_context_create();
    exit(0);
}
